Crow Facts for Google App Engine

SMS gateway by Quinn Mahoney
Puzzle by Kristen Sunter

Getting Started
===

There are four important files for this app:
- app.yaml, which defines the files for this app
- queue.yaml, which defines the task queue for this app
- cf-puzzle.py, which contains the interface for the puzzle
- facts.py, which contains (most of) the puzzle content and trivia answers

To get this or something similar working, you'll need a Google App Engine account (free) and a Twilio account (demo accounts are free). You'll need some familiarity with Google App Engine and how to upload an app with the App Engine Launcher.

Here's an intro to Twilio on App Engine:
https://developers.google.com/appengine/articles/twilio

And here's an intro to SMS messaging with Twilio on App Engine: https://www.twilio.com/docs/quickstart/python/sms

Following that quickstart should be enough to get a simple app working.

Implementation
===
When a user sends an SMS message to the given phone number, we process the message, update user state, and add any responses to an outgoing queue. A task queue handler runs through the outgoing SMS queue.

If a user calls the phone number, we play back an MP3 of crows cawing.

There's also a demo mode which allows you to test the application logic without a phone, and a statistics page for tracking during the Hunt.

All of these URLs are defined at the bottom of cf-puzzle.py, in the call to webapp2.WSGIApplication().

