import random
import datetime

# App Engine API
import webapp2
from google.appengine.ext import ndb
from google.appengine.api import taskqueue

# Twilio API
from twilio import twiml
from twilio.rest import TwilioRestClient

# Puzzle facts
import facts

# Twilio account information
account_phone_number = '+16175550000'
account_sid = 'AXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
auth_token = 'YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY'
client = TwilioRestClient(account_sid, auth_token)

# Return this XML when someone calls the Twilio number. It simply plays the MP3 back to them.
crow_sound_xml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
<Play>http://cf-puzzle.appspot.com/static/crows.mp3</Play>
</Response>
"""

# Return this empty Response object when receiving text messages.
empty_response_xml = """<?xml version="1.0" encoding="UTF-8"?>
<Response />
"""

# Model for the user data
class UserState(ndb.Model):
	# Phone number (this should probably be the NDB key, but it doesn't really matter here)
	phone_number = ndb.StringProperty(indexed=True,required=True)
	
	# Keep track of users that have chosen to unsubscribe, to be compliant with Twilio's guidelines.
	subscribed = ndb.BooleanProperty(required=True,default=True)
	
	# Puzzle info
	puzzle_step = ndb.IntegerProperty(default=0)
	favorite_animal = ndb.StringProperty(indexed=False,default='Crow')
	max_puzzle_step = ndb.IntegerProperty(default=0)
	
	# Statistics
	first_datetime = ndb.DateTimeProperty(auto_now_add=True,required=True)
	last_datetime = ndb.DateTimeProperty(auto_now=True,required=True)
	message_count = ndb.IntegerProperty(default=0,required=True)
	
# http://cf-puzzle.appspot.com/ shouldn't have any info on it
class Index(webapp2.RequestHandler):
	def get(self):
		self.response.headers['Content-Type'] = 'text/html'
		self.response.write('CF')

# Query the datastore. If user doesn't exist, create a new UserState object		
def retrieve_or_create_user(sms_sender):
	state = UserState.query(UserState.phone_number==sms_sender).get()
	if not state:
		state = UserState(phone_number=sms_sender)
	return state

# Query the datastore. Return true if the user exists.
def user_exists(sms_sender):
	state = UserState.query(UserState.phone_number==sms_sender).get()
	return state is not None

# Take any incoming message and convert to lowercase, remove spaces.	
def standardize_message(message):
	return message.lower().replace(' ','')

def create_responses(state, message):

	"""
	Process the message, update user state, and return any response messages.
	
	In general, a correct answer to a trivia question moves the user up one step,
	and earns them a new trivia question. If they send an incorrect answer,
	they'll get the trivia question again.
	
	If they choose to unsubscribe, then we record that in the database and
	never send them another SMS message, unless they send "START" again.
	
	One of the steps asks for their favorite bird. Any answer is correct, and we store it for later.
	"""	
	
	responses = []
	
	# Add the incoming message to the message count
	state.message_count += 1
	
	# Use lowercase, and remove spaces
	standardized_message = standardize_message(message)
	
	# If the user sends START or YES, reset state and subscribe them
	if standardized_message in ('start', 'yes'):
		state.puzzle_step = 0
		state.favorite_animal = 'Crow'
		state.subscribed = True # Make sure user is marked as subscribed
		
	# If user is unsubscribed, don't respond
	if not state.subscribed:
		return None
	
	# If the user is already unsubscribed, keep them unsubscribed
	# Unsubscribe the user if they send STOP, UNSUBSCRIBE, CANCEL, or QUIT
	if standardized_message in ('stop', 'unsubscribe', 'cancel', 'quit'):
		# Mark as unsubscribed, save state, and return no response
		state.subscribed = False
		responses.append("You will not receive any more messages from this number. Reply START to try again.")
		return responses
	
	# Ensure we haven't gone past the end
	if state.puzzle_step >= len(facts.steps):
		state.puzzle_step = len(facts.steps) - 1
	
	# Check if the answer is correct
	got_correct = False
	fact_prefix = ''

	if state.puzzle_step == 3:

		# Anything's correct for step 3
		got_correct = True
		state.favorite_animal = message
		if 'crow' in standardize_message(message):
			fact_prefix = 'CORRECT! '
		else:
			fact_prefix = 'Incorrect. '
			
	elif state.puzzle_step == 8:
	
		# Anything's correct for step 8
		got_correct = True
		if 'crow' in standardize_message(message) and 'crow' in standardize_message(state.favorite_animal):
			fact_prefix += 'CORRECT! Your favorite bird is the crow!'
		elif standardize_message(message) == standardize_message(state.favorite_animal):
			fact_prefix += 'STILL INCORRECT: Your favorite bird is the crow!'
		else:
			fact_prefix += 'INCORRECT: You said your favorite bird is the ' + state.favorite_animal + '.'
	
	elif standardize_message(message) == facts.steps[state.puzzle_step]['answer']:
		
		# Correct answer for other steps
		got_correct = True
	
	# Go to the next step if correct, don't go past the end.
	if got_correct and state.puzzle_step + 1 < len(facts.steps):
		state.puzzle_step += 1
		
	# Include full fact text if it's the first step or a new step
	if (state.puzzle_step == 0 or got_correct) and len(facts.steps[state.puzzle_step]['facts']) > 0:
		responses += facts.steps[state.puzzle_step]['facts']
		# Use the prefix
		responses[0] = fact_prefix + responses[0]
		
	# Include the trivia question
	responses += [facts.steps[state.puzzle_step]['trivia'],]
	
	# Cut the responses down to less than 160 characters
	for i in range(len(responses)):
		if len(responses[i]) >= 160:
			responses[i] = responses[i][:156] + '...'
	
	# Add the # of responses to the message count
	state.message_count += len(responses)
	
	# Set the maximum puzzle step
	state.max_puzzle_step = max(state.max_puzzle_step, state.puzzle_step)

	return responses

# Respond to a text message		 
class Respond(webapp2.RequestHandler):

	"""
	Handle every incoming SMS or XMLHttpRequest from the demo page.
	
	We use the 'from' phone number to retrieve the user's information,
	then determine the response. For SMS users, we add all the responses
	to an outgoing queue. For demo users, we simply return it in the page content.
	"""

	def post(self):

		# Get the POST data
		sms_sender = self.request.get('From')
		message = self.request.get('Body')
		
		# Retrieve the user
		state = retrieve_or_create_user(sms_sender)
	
		# Create the response
		responses = create_responses(state, message)
		
		# Save state
		state.put()
	
		# Return if there are no responses (unsubscribed)
		if responses is None:
			return
		
		# Send the response
		if sms_sender.startswith('demo'):
			# As text, for the demo page
			self.response.headers['Content-Type'] = 'text/plain'
			response = '\n'.join(responses)
			response = response.replace('<', '&lt;').replace('>', '&gt;').replace('\n','<br>')
			self.response.write(response)
		else:
			# For each response, add it to the task queue
			for i, response in enumerate(responses):
				
				# Set the countdown for this SMS, hopefully this will help keep the texts in order
				countdown = i*2
				
				# Or add this SMS to the task queue
				taskqueue.add(queue_name='sms', url='/sendsms', countdown=countdown, params={'to': sms_sender, 'body': response})
			
			# Send an empty response back to Twilio
			self.response.headers['Content-Type'] = 'text/xml'
			self.response.write(empty_response_xml)

# Send an SMS from the task queue				
class SendSMS(webapp2.RequestHandler):

	"""
	Process the outgoing SMS task queue.
	
	(Please read Google's documentation on GAE task queues.)
	
	For every outgoing SMS, we take the user's phone number,
	make sure we've communicated with them before, and send the message.
	
	Note that we do *not* check if the user is subscribed or not. Otherwise we wouldn't be
	able to send an acknowledgement when they unsubscribe.
	"""

	def post(self):
		# Get the sender and SMS responses
		to = self.request.get('to')
		body = self.request.get('body')

		# Never send an SMS to someone not in the database
		if not user_exists(to):
			return
	
		# Send via Twilio
		sms = client.sms.messages.create(to=to, from_=account_phone_number, body=body)	

# HTML for statistics
statistics_html = """<html>
<head>
<style type="text/css">
body
{
  margin: 0;
  padding: 0;
}
div { width: 100%% }
table
{
  color: #888;
  margin: 50px auto 0 auto;
}
td
{
  width: 200px;
  text-align: center;
}
tr.important
{
  font-size: large;
  font-weight: bold;
  color: #000;
}
td.spacer { height: 20px; }
</style>
</head>
<body>
<div>
<table>
<tr class="important"><td /><td /><td>Since Friday at noon</td></tr>
<tr><td /><td /><td><small>%(friday_noon)s</small></td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr class="important"><td>SMS users</td><td>%(phone_users)d</td><td>%(friday_phone_users)d</td></tr>
<tr><td>Demo users</td><td>%(demo_users)d</td><td>%(friday_demo_users)d</td></tr>
<tr><td>Total users</td><td>%(total_users)d</td><td>%(friday_total_users)d</td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr class="important"><td>SMS messages</td><td>%(phone_messages)d</td><td>%(friday_phone_messages)d</td></tr>
<tr><td>Demo messages</td><td>%(demo_messages)d</td><td>%(friday_demo_messages)d</td></tr>
<tr><td>Total messages</td><td>%(total_messages)d</td><td>%(friday_total_messages)d</td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr class="important"><td>Approximate Twilio cost</td><td>$%(approximate_cost).2f</td><td>$%(friday_approximate_cost).2f</td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr><td rowspan="2">Reached end</td><td>%(reached_end)d</td><td>%(friday_reached_end)d</td></tr>
<tr><td>%(reached_end_pct).1f%%</td><td>%(friday_reached_end_pct).1f%%</td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr class="important"><td>Average time to finish</td><td>%(average_minutes_spent_finished).1f minutes</td><td>%(friday_average_minutes_spent_finished).1f minutes</td></tr>
<tr><td>Average time spent</td><td>%(average_minutes_spent).1f minutes</td><td>%(friday_average_minutes_spent).1f minutes</td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr><td>Unsubscribed from SMS</td><td>%(unsubscribed)d</td><td>%(friday_unsubscribed)d</td></tr>
<tr><td colspan="3" class="spacer"/></tr>

<tr class="important"><td>Tasks in queue</td><td>%(tasks_in_queue)d</td></tr>
<tr class="important"><td>Tasks in the last minute</td><td>%(tasks_in_last_minute)d</td></tr>

</table>
</div>
</body>
</html>
"""

def calculate_friday_at_noon():

	"""
	Return a datetime object for the most recent Friday at noon EST.
	
	(That's when the MIT Mystery Hunt starts.)
	"""

	current_time = datetime.datetime.now()

	# Get friday, one week ago, at 12 o'clock EST
	last_friday = (current_time.date() - datetime.timedelta(days=current_time.weekday()) + datetime.timedelta(days=4, weeks=-1))
	last_friday_at_12 = datetime.datetime.combine(last_friday, datetime.time(7))

	# If today is also friday, and after 12 o'clock, change to the current date
	one_week = datetime.timedelta(weeks=1)
	if current_time - last_friday_at_12 >= one_week:
		last_friday_at_12 += one_week
		
	return last_friday_at_12

def calculate_statistics(query):

	"""
	Calculate statistics both for all time and starting from Friday at noon.
	
	Yes, there's a lot of duplicate stuff here, and I could simplify. But I'm not going to.
	"""
	
	data = {
		'total_users': 0,
		'friday_total_users': 0,

		'demo_users': 0,
		'phone_users': 0,
		'friday_demo_users': 0,
		'friday_phone_users': 0,

		'total_messages': 0,
		'friday_total_messages': 0,

		'demo_messages': 0,
		'phone_messages': 0,
		'friday_demo_messages': 0,
		'friday_phone_messages': 0,
		
		'reached_end': 0,
		'friday_reached_end': 0,
		'unsubscribed': 0,
		'friday_unsubscribed': 0,
	}
	
	# Get the datetime of Friday at noon
	friday_noon = calculate_friday_at_noon()
	data['friday_noon'] = str(friday_noon) + ' UTC'
	
	total_time_spent = datetime.timedelta(0)
	friday_total_time_spent = datetime.timedelta(0)
	total_time_spent_finished = datetime.timedelta(0)
	friday_total_time_spent_finished = datetime.timedelta(0)
	
	for state in query.iter():
	
		# See if this has been modified recently
		recently = state.first_datetime > friday_noon
		time_spent = state.last_datetime - state.first_datetime
	
		# Count total users
		data['total_users'] += 1
		if recently:
			data['friday_total_users'] += 1
		
		# Count total messages
		data['total_messages'] += state.message_count
		if recently:
			data['friday_total_messages'] += state.message_count

		# Count phone users, demo users
		if state.phone_number.startswith('demo'):
			data['demo_users'] += 1
			data['demo_messages'] += state.message_count
			if recently:
				data['friday_demo_users'] += 1
				data['friday_demo_messages'] += state.message_count
		else:
			data['phone_users'] += 1
			data['phone_messages'] += state.message_count
			if recently:
				data['friday_phone_users'] += 1
				data['friday_phone_messages'] += state.message_count
				
			if not state.subscribed:
				data['unsubscribed'] += 1
				if recently:
					data['friday_unsubscribed'] += 1
				
		if state.max_puzzle_step >= 9:
			data['reached_end'] += 1
			total_time_spent_finished += time_spent
			if recently:
				data['friday_reached_end'] += 1
				friday_total_time_spent_finished += time_spent
				
		total_time_spent += time_spent
		if recently:
			friday_total_time_spent += time_spent
		
	data['approximate_cost'] = 0.0075 * data['phone_messages']
	data['friday_approximate_cost'] = 0.0075 * data['friday_phone_messages']
	
	if data['total_users'] != 0:
		data['average_minutes_spent'] = total_time_spent.total_seconds() / data['total_users'] / 60.0
	else:
		data['average_minutes_spent'] = 0

	if data['friday_total_users'] != 0:
		data['friday_average_minutes_spent'] = friday_total_time_spent.total_seconds() / data['friday_total_users'] / 60.0
	else:
		data['friday_average_minutes_spent'] = 0

	if data['reached_end'] != 0:
		data['average_minutes_spent_finished'] = total_time_spent_finished.total_seconds() / data['reached_end'] / 60.0
	else:
		data['average_minutes_spent_finished'] = 0
	
	if data['friday_reached_end'] != 0:
		data['friday_average_minutes_spent_finished'] = friday_total_time_spent_finished.total_seconds() / data['friday_reached_end'] / 60.0
	else:
		data['friday_average_minutes_spent_finished'] = 0
	
	if data['total_users'] != 0:
		data['reached_end_pct'] = data['reached_end'] * 100.0 / data['total_users']
	else:
		data['reached_end_pct'] = 0
	
	if data['friday_total_users'] != 0:
		data['friday_reached_end_pct'] = data['friday_reached_end'] * 100.0 / data['friday_total_users']
	else:
		data['friday_reached_end_pct'] = 0
		
	queueStats = taskqueue.QueueStatistics.fetch(taskqueue.Queue('sms'))
	data['tasks_in_queue'] = queueStats.tasks
	data['tasks_in_last_minute'] = queueStats.executed_last_minute
	if data['tasks_in_last_minute'] is None:
		data['tasks_in_last_minute'] = 0

	return data

class Statistics(webapp2.RequestHandler):

	"""
	Print out a page of statistics about app users.
	"""

	def get(self):

		stats = calculate_statistics(UserState.query())

		self.response.headers['Content-Type'] = 'text/html'
		self.response.write(statistics_html%stats)
		
# Demo HTML for testing
demo_html = """<html>
<head>
<style type="text/css">
div.message  {font-style: italic; padding-top: 5px; padding-bottom: 5px;}
div.response {font-weight: bold;}
</style>
<script type="text/javascript">
function send()
{
	var message = document.forms[0]["text"].value;
	document.getElementsByTagName("body")[0].innerHTML += "<div class=\\\"message\\\">" + message + "</div>";
	
	var params = "From=%s&Body="+message;
	x = new XMLHttpRequest();
	x.open("POST","/respond",true);
	x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	x.setRequestHeader("Content-length", params.length);
	x.setRequestHeader("Connection", "close");
	x.onreadystatechange=function()
	  {
	  if (x.readyState==4 && x.status==200)
		{
			document.getElementsByTagName("body")[0].innerHTML += "<div class=\\\"response\\\">" + x.responseText + "</div>";
		}
	  }
	x.send(params);
}
</script>
</head>
<body>
<div class="response">Why is a crow like a writing desk? To find out, enter 'START'.</div>
<div>
  <form onsubmit="send(); return false;">
  <input type="text" name="text" autofocus />
  <input type="submit" value="Send" />
  </form>
</div>
</body>
</html>
"""

class Demo(webapp2.RequestHandler):

	"""
	Display a page that runs a demo of the puzzle.
	
	(You can use this for testing instead of text messages.)
	"""

	# Send the demo HTML, giving a random demo ID
	def get(self):
		self.response.headers['Content-Type'] = 'text/html'
		id = 'demo' + str(random.randrange(10000));
		self.response.write(demo_html%id)
		
class Voice(webapp2.RequestHandler):

	"""
	Handle incoming phone calls.
	
	We do not need this for the puzzle, but we have an MP3 of crows cawing as an easter egg.
	"""
	
	def post(self):
		self.response.headers['Content-Type'] = 'text/xml'
		self.response.write(crow_sound_xml)

# Register URLs for Google App Engine 
application = webapp2.WSGIApplication([ ('/', Index),
										('/respond', Respond),
										('/demo', Demo),
										('/voice', Voice),
										('/sendsms', SendSMS),
										('/statistics', Statistics),
									  ],
									  debug=True)
										
