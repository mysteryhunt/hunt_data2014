
steps = [

{'facts':   ['Thanks for signing up for Crow Facts! You now will receive fun daily facts about CROWS! (*v*)\nCrow Fact #1: A crow gets what it earns, when it earns it.',],
 'trivia': 'To continue receiving Daily Crow Facts, reply \'crow\'',
 'answer': 'crow',
 },

{'facts':   ['Thanks for subscribing to Crow Facts!\nCrow Fact #4: There\'s nothing more sickening than a crow in love.',],
 'trivia': 'Would you like to receive a Crow Fact every hour?\nReply \'Tyxt3358dggyf\' to continue',
 'answer': 'tyxt3358dggyf',
 },
 
{'facts':   ['You now have a <year> subscription to Crow Facts and will receive fun <hourly> updates!\nCrow Fact #7: The crows serve crueler gods than you or I.',],
 'trivia': 'To continue receiving Hourly Crow Facts, complete this sequence: qazwsxedc _ _ _',
 'answer': 'rfv',
 },

{'facts':   ['You are subscribed to Crow Facts, your source for fascinating facts about crows!\nCrow Fact #9: What crows want most of all is to be a hero.',],
 'trivia': 'Please let us know you are human to continue by completing the following sentence: Your favorite bird is the ________.',
 'answer': 'crow',
 },

{'facts':   ['Your favorite bird is the crow. You will continue to receive Crow Facts every <hour>. Welcome to Crow Facts!', 'Crow Fact #6: A crow won\'t hack a man\'s head off, but it can poke him full of holes.',],
 'trivia': 'To continue, find a YouTube video of a crow getting a peanut out of a box: www.youtube.com/watch?v=_________',
 'answer': 'ewc_rssuyik',
 },

{'facts':   ['Thanks for texting Crow Facts! Remember, every time you text you will receive an instant Crow Fact!', 'Crow Fact #10: Crows have their own rules, their own reasons, and you\'ll never know them.',],
 'trivia': 'To continue, reply with the scientific name for the species of crow well known for making tools such as hooks.',
 'answer': 'corvusmoneduloides',
 },

{'facts':   ['Thank you for subscribing to Crow Facts!\nCrow Fact #3: Now crows are here, at the end of the world, with no one to sing for but old men.',],
 'trivia': 'To continue, reply with the dactyly of corvids.',
 'answer': 'anisodactyly',
 },

{'facts':   ['You are subscribed to Crow Facts, the internet\'s #1 source for facts about crows.', 'Crow Fact #7: The crows here grew up in a castle, spitting down on the likes of you.',],
 'trivia': 'To continue, reply with the one that does not belong: enca, fuscicapillus, ossifragus, typicus, validus.',
 'answer': 'ossifragus',
 },

{'facts':   ['Thanks for choosing Crow Facts!\nCrow Fact #5: Crows don\'t like high places.',],
 'trivia': 'You want to continue? Please answer the following question to confirm you\'re human: Your favorite bird is the ________.',
 'answer': 'crow',
 },

{'facts':   ['', 'Crow Fact #12: Sooner or later, in every crow\'s life, there comes a day when it is not easy.',],
 'trivia': 'Please submit the answer to cancel Crow Facts.',
 'answer': 'birdofprey',
 },

{'facts':   [],
 'trivia': 'Please call in the answer to cancel Crow Facts.',
 'answer': 'NOANSWER',
 },

]

if __name__ == '__main__':
	for item in steps:
		for line in item['facts'] + [item['trivia'],]:
			print '%4d'%len(line), line
		print
		print
