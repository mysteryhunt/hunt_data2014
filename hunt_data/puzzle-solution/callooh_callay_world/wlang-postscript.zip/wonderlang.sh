#!/bin/bash

# Wonderlang interpreter
# compiles all .wl files in current directory into PostScript
# then runs given file as PostScript program file with extra definitions
#
#  $ bash wonderlang.sh [FILE]
#
# .wl files can be in either HTML or unformatted UTF-8.


if [ -z $1 ]
then
    echo "ERROR: Missing program file."
    echo "Usage: $ wonderlang [FILE]"
    exit
fi

# compile files in directory
for file in *.wl
do
    sed -f compile.sed < $file > $file.ps
done

# run PostScript

gs -q -dNODISPLAY -dNOPROMPT wonderlang.ps $1.ps finish.ps
