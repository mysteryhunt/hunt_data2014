// written for the MIT Mystery Hunt 2014
// author: James Clark (sbj@dimins.com)
function EscapeException(message) {
    this.message = message;
}
