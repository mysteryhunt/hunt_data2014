from geom import *
from actor import *

class Runner(Actor):
    def __init__(self, ch, loc, speed):
        super(Runner, self).__init__(ch, loc)
        self.speed = speed
    def act(self, zone, settle):
        for i in range(self.speed):
            if not self.act_inner(zone, settle):
                return False
        return True
    def act_inner(self, zone, settle):
        dr = zone.player.loc.r - self.loc.r
        dc = zone.player.loc.c - self.loc.c
        h = abs(dr) > abs(dc)
        dc = -1 if dc < 0 else dc
        dc = 1 if dc > 0 else dc
        dr = -1 if dr < 0 else dr
        dr = 1 if dr > 0 else dr
        if h:
            if dr == 0 or zone.actor_push(self, Delta(0, dr)):
                return True
        else:
            if dc == 0 or zone.actor_push(self, Delta(dc, 0)):
                return True
        if not settle:
            return False
        if not h:
            if dr != 0:
                zone.actor_push(self, Delta(0, dr))
        else:
            if dc != 0:
                zone.actor_push(self, Delta(dc, 0))
        return True
