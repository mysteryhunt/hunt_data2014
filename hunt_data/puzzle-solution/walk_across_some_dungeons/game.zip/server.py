import os
import http.server
import http.cookies
import socketserver
import sys
import shutil
import time
import random
import urllib.parse
import traceback
import cProfile

try:
    os.mkdir("logs")
except:
    pass

import session

running = True

timing = open("logs/timing.txt", "a+", 1)
sessions = dict()

class Handler(http.server.BaseHTTPRequestHandler):
    def address_string(self):
        return str(self.client_address[0])
    def do_GET(self):
        start = time.clock()
        addr = self.headers["X-Forwarded-For"] or self.client_address[0]
        zoneid = -1
        global running
        global sessions
        if self.path == "/__________wasdinfo__________":
            self.send_header("Content-Type", "text/html")
            self.send_response(200)
            self.end_headers()
            self.wfile.write(bytes("<a href=\"/main\">main</a><br />", "UTF-8"))
            self.wfile.write(bytes("<table><tr><th>sessid<th>address<th>last usage<th>level<th>action count<th>death count", "UTF-8"))
            for sessid in sessions:
                sess = sessions[sessid]
                usage = time.strftime("%m/%d %H:%M:%S",time.localtime(sess.last_action))
                self.wfile.write(bytes("<tr><td>%s<td>%s<td>%s<td>%d<td>%d<td>%d" % (sessid, str(sess.addr), usage, sess.zoneid, sess.action_count, sess.death_count), "UTF-8"))
            self.wfile.write(bytes("</table>", "UTF-8"))
        elif self.path == "/quit" and len(sys.argv) == 2 and sys.argv[1] == "test":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(open("data/quit.html", "rb").read())
            running = False
        elif self.path == "/main":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(open("data/main.html", "rb").read())
        elif self.path[:6] == "/goto?" or self.path[:8] == "/action?":
            sess = None
            setcookie = None
            lasthash = None
            if "Cookie" in self.headers:
                c = http.cookies.SimpleCookie(self.headers["Cookie"])
                if "session" in c:
                    sessid = c["session"].value
                    if sessid in sessions:
                        sess = sessions[sessid]
                if "lasthash" in c:
                    lasthash = c["lasthash"].value
            if not sess:
                sessid = str(int(time.time()))+"-"+str(random.getrandbits(64))
                c = http.cookies.SimpleCookie()
                c["session"] = sessid
                setcookie = c.output(header="")
                sessions[sessid] = sess = session.Session(addr)
                sess.set_last_hash(lasthash)
            zoneid = sess.zoneid
            if self.path[:6] == "/goto?":
                qs = urllib.parse.parse_qs(self.path[6:])
                if not "hash" in qs or len(qs["hash"]) != 1:
                    self.send_error(400)
                    return
                hash = qs["hash"][0]
                try:
                    sess.goto(hash)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    if setcookie:
                        self.send_header("Set-Cookie", setcookie)
                    self.end_headers()
                    self.wfile.write(sess.render())
                except Exception as e:
                    self.send_error(400, str(e))
                    traceback.print_exc(file=sys.stdout)
            elif self.path[:8] == "/action?":
                qs = urllib.parse.parse_qs(self.path[8:])
                if not "key" in qs or len(qs["key"]) != 1:
                    self.send_error(400)
                    return
                key = qs["key"][0]
                try:
                    sess.action(key)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    if setcookie:
                        self.send_header("Set-Cookie", setcookie)
                    self.end_headers()
                    self.wfile.write(sess.render())
                except Exception as e:
                    self.send_error(400, str(e))
                    traceback.print_exc(file=sys.stdout)
            else:
                self.send_error(404, self.path)
        else:
            self.send_error(404, self.path)
        timing.write("%s\t%02d\t\%s\t%f\n" % (addr, zoneid, self.path, time.clock() - start))

#pr = cProfile.Profile()
#pr.enable()
try:
    server = socketserver.TCPServer(("", 8080), Handler)
    while running:
        server.handle_request()
    server.server_close()
except KeyboardInterrupt:
    server.server_close()
#pr.disable()
#pr.print_stats("cum")
