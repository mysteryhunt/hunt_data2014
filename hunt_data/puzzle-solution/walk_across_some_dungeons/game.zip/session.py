import json
import time
import hashlib
import sys

from zone import *

log = open("logs/events.txt", "a+", 1)
escapes = open("logs/escapes.txt", "a+", 1)
deaths = open("logs/deaths.txt", "a+", 1)

class Session:
    def __init__(self, addr):
        self.addr = addr
        self.death_count = 0
        self.zoneid = 1
        self.zonehashes = dict()
        self.last_action = time.time()
        self.last_level = 1
        for i in range(1,21):
            self.zonehashes[self.zonehash(i)] = i
        self.reset()

    def logprint(self, msg):
        log.write("%s\t%s\t%s\n" % (time.strftime("%m/%d %H:%M:%S",time.localtime(time.time())), self.addr, msg))

    def reset(self):
        self.action_count = 0
        self.curzone = None

    def zone(self):
        if not self.curzone or self.zoneid != self.curzone.id:
            self.curzone = Zone(self.zoneid)
        return self.curzone

    def zonehash(self, zoneid):
        return hashlib.md5(bytes("fhqwhgads%d" % (zoneid*683+924), "UTF-8")).hexdigest()

    def render(self):
        self.last_level = max(self.last_level, self.zoneid)
        data = {
          "level": self.zoneid,
          "hash": self.zonehash(self.zoneid),
          "board": self.zone().render()
        }
        if self.last_level > self.zoneid:
            data["next"] = self.zonehash(self.zoneid+1)
        if self.last_level > 1:
            data["prev"] = self.zonehash(self.zoneid-1)
        return bytes(json.dumps(data), "UTF-8")

    def action(self, key):
        if key == "0":
            return
        elif key == "27" and len(sys.argv) == 2 and sys.argv[1] == "test":
            self.zoneid = 1
            self.reset()
            return
        elif key == "192" and len(sys.argv) == 2 and sys.argv[1] == "test":
            if self.zoneid == 20:
                return
            self.zoneid += 1
            self.reset()
            return
        self.last_action = time.time()
        self.action_count += 1
        try:
            self.zone().action(key)
        except BadActionException as e:
            self.logprint("%02d\t\t%s" % (self.zoneid, e.value))
        except DeathException as e:
            self.logprint("%02d\t%d\t%s" % (self.zoneid, len(self.zone().moves), e.value))
            deaths.write("%02d\t%s\t%d\t%s\n" % (self.zoneid, self.addr, len(self.zone().moves), e.value))
            self.death_count += 1
            self.reset()
        except EscapeException:
            self.logprint("%02d\t%d\t%s" % (self.zoneid, len(self.zone().moves), "".join(self.zone().moves)))
            escapes.write("%02d\t%s\t%d\t%s\n" % (self.zoneid, self.addr, len(self.zone().moves), "".join(self.zone().moves)))
            self.zoneid += 1
            self.reset()

    def set_last_hash(self, hash):
        if hash in self.zonehashes:
            self.last_level = self.zonehashes[hash]
        else:
            self.logprint("bad hash")

    def goto(self, hash):
        if hash in self.zonehashes:
            self.logprint("%02d\t\tabandoned" % (self.zoneid))
            self.zoneid = self.zonehashes[hash]
            self.reset()
        else:
            self.logprint("bad hash")
