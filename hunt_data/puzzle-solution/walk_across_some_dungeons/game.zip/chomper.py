from util import *
from geom import *
from actor import *

class Chomper(Actor):
    def __init__(self, ch, loc, speed, initiative):
        super(Chomper, self).__init__(ch, loc)
        if initiative < 0:
            self.loc = Location(-self.loc.c, -self.loc.r)
            initiative = -initiative
        self.speed = speed
        self.initiative = initiative
    def tick(self):
        if self.initiative:
            self.initiative -= 1
        else:
            self.initiative = self.speed-1
    def act(self, zone, settle):
        if self.initiative:
            return True
        self.loc = Location(-self.loc.c, -self.loc.r)
        if zone.player.loc == self.loc:
            raise DeathException("player chomped by "+str(self))
        return True
