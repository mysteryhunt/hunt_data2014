from util import *
from actor import Actor

class Arrow(Actor):
    def __init__(self, ch, loc, delta):
        super(Arrow, self).__init__(ch, loc)
        self.delta = delta
    def act(self, zone, settle):
        if zone.actor_push(self, self.delta, fly=True):
            return True
        zone.enemies.remove(self)
        return True

class Archer(Actor):
    def __init__(self, ch, loc, delta, speed, initiative):
        super(Archer, self).__init__(ch, loc)
        self.delta = delta
        self.speed = speed
        self.initiative = initiative
    def tick(self):
        if self.initiative:
            self.initiative -= 1
        else:
            self.initiative = self.speed-1
    def act(self, zone, settle):
        if self.initiative:
            return True
        if not zone.floor_at(self.loc + self.delta).walkable():
            return True
        e = zone.enemy_at(self.loc + self.delta)
        if e and e.ch != "a" and e.ch != "#":
            return True
        a = Arrow("a", self.loc + self.delta, self.delta)
        zone.enemies.append(a)
        if zone.player.loc == a.loc:
            raise DeathException("player hit at point blank range by "+str(a))
        return True
