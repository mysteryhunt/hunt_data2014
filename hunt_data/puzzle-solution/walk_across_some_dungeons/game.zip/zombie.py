from geom import *
from actor import *

class Zombie(Actor):
    def __init__(self, ch, loc, speed, initiative):
        super(Zombie, self).__init__(ch, loc)
        self.speed = speed
        self.initiative = initiative
    def tick(self):
        if self.initiative:
            self.initiative -= 1
        else:
            self.initiative = self.speed-1
    def act(self, zone, settle):
        if self.initiative:
            return True
        dr = zone.player.loc.r - self.loc.r
        dc = zone.player.loc.c - self.loc.c
        h = abs(dr) > abs(dc)
        dc = -1 if dc < 0 else dc
        dc = 1 if dc > 0 else dc
        dr = -1 if dr < 0 else dr
        dr = 1 if dr > 0 else dr
        if h:
            if dr == 0 or zone.actor_push(self, Delta(0, dr)):
                return True
        else:
            if dc == 0 or zone.actor_push(self, Delta(dc, 0)):
                return True
        if not settle:
            return False
        if not h:
            if dr != 0:
                zone.actor_push(self, Delta(0, dr))
        else:
            if dc != 0:
                zone.actor_push(self, Delta(dc, 0))
        return True
