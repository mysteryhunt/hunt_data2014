from util import *
from actor import Actor

class Golem(Actor):
    def __init__(self, ch, loc, delta, speed, initiative):
        super(Golem, self).__init__(ch, loc)
        self.delta = delta
        self.speed = speed
        self.initiative = initiative
    def tick(self):
        if self.initiative:
            self.initiative -= 1
        else:
            self.initiative = self.speed-1
    def act(self, zone, settle):
        if self.initiative:
            return True
        if zone.actor_push(self, self.delta):
            return True
        return True
