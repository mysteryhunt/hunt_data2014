class Actor:
    def __init__(self, ch, loc):
        self.ch = ch
        self.loc = loc
    def __str__(self):
        return "%c" % self.ch
    def tick(self):
        pass
    def act(self, zone, settle):
        return True
