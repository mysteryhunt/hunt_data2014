class Delta:
    def __init__(self, dc, dr):
        self.dc = dc
        self.dr = dr
    def __repr__(self):
        return "<%d,%d>" % (self.dc, self.dr)
    def __eq__(self, other):
        return self.dc == other.dc and self.dr == other.dr
    def __ne__(self, other):
        return not self.__eq__(other)
    def __add__(self, other):
        if other is None:
            return self
        return Delta(self.dc + other.dc, self.dr + other.dr)
    def __sub__(self, other):
        if other is None:
            return self
        return Delta(self.dc - other.dc, self.dr - other.dr)

def make_delta(d):
    if d == "W":
        return Delta(0, -1)
    elif d == "D":
        return Delta(1, 0)
    elif d == "A":
        return Delta(-1, 0)
    elif d == "S":
        return Delta(0, 1)
    return None

class Location:
    def __init__(self, c, r):
        self.c = c
        self.r = r
    def __repr__(self):
        return "(%d,%d)" % (self.c, self.r)
    def __eq__(self, other):
        return self.c == other.c and self.r == other.r
    def __ne__(self, other):
        return not self.__eq__(other)
    def __add__(self, other):
        if other is None:
            return self
        return Location(self.c + other.dc, self.r + other.dr)
    def __sub__(self, other):
        if other is None:
            return self
        return Location(self.c - other.dc, self.r - other.dr)
    def distance(self, other):
        return abs(self.r - other.r)+abs(self.c - other.c)
