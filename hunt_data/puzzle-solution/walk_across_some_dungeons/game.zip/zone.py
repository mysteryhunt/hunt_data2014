from actor import *
from zombie import *
from runner import *
from archer import *
from golem import *
from chomper import *
from util import *
from geom import *

class Floor:
    def __init__(self, ch):
        self.ch = ch
        self.warp = -1
    def __repr__(self):
        return "%c" % self.ch
    def walkable(self):
        return self.ch in " >%$()"

class Zone:
    def __init__(self, zoneid):
        self.id = zoneid
        mapfile = open("data/map%02d.txt" % zoneid)
        lines = []
        self.width = 0
        while True:
            line = mapfile.readline().rstrip("\n")
            if line == "":
                break
            self.width = max(self.width, len(line))
            lines.append(line)
        legend = dict()
        while True:
            line = mapfile.readline().rstrip("\n")
            if line == "":
                break
            legend[line[0]] = line[1:]
        automatic = "@#O"
        self.height = len(lines)
        self.floors = []
        self.enemies = []
        self.coins = 0
        self.exit = None
        self.warps = dict()
        self.rarr = None
        self.moves = []
        for r in range(self.height):
            for c, ch in enumerate(lines[r].ljust(self.width, ' ')):
                if ch in legend:
                    stuff = legend[ch]
                elif ch in automatic:
                    stuff = " "+ch
                else:
                    stuff = ch+ch
                fl = stuff[0]
                self.floors.append(Floor(fl))
                if fl == "$":
                    self.coins += 1
                ch = stuff[1]
                param = stuff[2:].split()
                if ch == "@":
                    self.player = Actor(ch, Location(c, r))
                elif ch == ">":
                    self.exit = Location(c, r)
                elif ch == "%":
                    warp = int(param[0])
                    self.floors[-1].warp = warp
                    if not warp in self.warps:
                        self.warps[warp] = []
                    self.warps[warp].append(Location(c, r))
                elif ch in "#O":
                    self.enemies.append(Actor(ch, Location(c, r)))
                elif ch in "i":
                    self.enemies.append(Runner(ch, Location(c, r), int(param[0])))
                elif ch in "gzZ":
                    self.enemies.append(Zombie(ch, Location(c, r), int(param[0]), int(param[1])))
                elif ch in "~":
                    self.enemies.append(Chomper(param[0], Location(c, r), int(param[1]), int(param[2])))
                elif ch == "A":
                    self.enemies.append(Archer(ch, Location(c, r), make_delta(param[0]), int(param[1]), int(param[2])))
                elif ch == "G":
                    self.enemies.append(Golem(ch, Location(c, r), make_delta(param[0]), int(param[1]), int(param[2])))

    def __str__(self):
        return "zone %d (%d x %d)" % (self.num, self.width, self.height)

    def floor_at(self, loc):
        if loc.r < 0 or loc.r >= self.height or loc.c < 0 or loc.c >= self.width:
            return Floor('+')
        return self.floors[loc.r * self.width + loc.c]

    def enemy_at(self, loc):
        f = self.floor_at(loc)
        if f.warp in self.warps:
            locs = self.warps[f.warp]
        else:
            locs = [loc]
        ret = None
        for a in self.enemies:
            if a.loc in locs:
                if ret and a.ch == '#':
                    continue
                ret = a
        return ret

    def actor_at(self, loc):
        f = self.floor_at(loc)
        if f.warp in self.warps:
            locs = self.warps[f.warp]
        else:
            locs = [loc]
        if self.player.loc in locs:
            return self.player
        return self.enemy_at(loc)

    def render_at(self, loc):
        f = self.floor_at(loc)
        if f.warp in self.warps:
            locs = self.warps[f.warp]
        else:
            locs = [loc]
        for loc in locs:
            i = loc.r * self.width + loc.c
            if i in self.rarr:
                return self.rarr[i]
        return f.ch

    def render(self):
        ret = []
        self.rarr = dict()
        for a in self.enemies:
            self.rarr[a.loc.r * self.width + a.loc.c] = a.ch
        self.rarr[self.player.loc.r * self.width + self.player.loc.c] = self.player.ch
        for r in range(self.height):
            row = []
            for c in range(self.width):
                row.append(self.render_at(Location(c, r)))
            ret.append("".join(row))
        return "\n".join(ret)

    def player_check(self):
        if self.exit and self.player.loc == self.exit:
            raise EscapeException("player was pushed out of level %02d" % self.id)
        f = self.floor_at(self.player.loc)
        if f.ch == "$":
            f.ch = " "
            self.coins -= 1
            if self.coins == 0:
                for f in self.floors:
                    if f.ch == ":":
                        f.ch = " "

    def actor_push(self, actor, delta, kill=True, fly=False):
        f = self.floor_at(actor.loc)
        if f.warp in self.warps:
            locs = self.warps[f.warp]
        else:
            locs = [actor.loc]
        for loc in locs:
            if not self.floor_at(loc + delta).walkable():
                continue
            e = self.actor_at(loc + delta)
            if fly and e and e.ch == "#":
                e = None
            if e and e.ch == "#":
                if actor is self.player:
                    raise DeathException("player was pushed into "+str(e))
                self.enemies.remove(actor)
                if actor.ch == "O":
                    self.enemies.remove(e)
            elif e:
                if kill and actor is self.player and e.ch != "O":
                    raise DeathException("player was pushed into "+str(e))
                if kill and e is self.player and actor.ch != "O":
                    raise DeathException("player collided with "+str(actor))
                continue
            else:
                actor.loc = loc + delta
            if actor is self.player:
                self.player_check()
            return True
        return False

    def player_move(self, delta):
        if not delta:
            return False
        f = self.floor_at(self.player.loc)
        if f.warp in self.warps:
            locs = self.warps[f.warp]
        else:
            locs = [self.player.loc]
        for loc in locs:
            e = self.enemy_at(loc + delta)
            if e and (e.ch == "-" or e.ch == "|"):
                continue
            if e and e.ch == "O":
                if not self.actor_push(e, delta, False):
                    continue
                e = self.enemy_at(loc + delta)
            f = self.floor_at(loc + delta)
            if not f.walkable():
                continue
            self.player.loc = loc + delta
            if e:
                raise DeathException("player walked into "+str(e))
            self.player_check()
            return True
        return False

    def conveyer(self, topush, kill):
        more = True
        while more:
            more = False
            for a in topush[:]:
                f = self.floor_at(a.loc)
                delta = None
                if f.ch == ")":
                    delta = 1
                elif f.ch == "(":
                    delta = -1
                if a.ch == "a":
                    delta = None
                if delta:
                    if self.actor_push(a, Delta(delta, 0), kill):
                        topush.remove(a)
                        more = True
                        break
                else:
                    topush.remove(a)

    def action(self, key):
        delta = None
        move = None
        if key == "37" or key == "65":
            move = "A"
        elif key == "38" or key == "87":
            move = "W"
        elif key == "39" or key == "68":
            move = "D"
        elif key == "40" or key == "83":
            move = "S"
        else:
            raise BadActionException("no such key %s" % key)
        if move:
            delta = make_delta(move)
        if not self.player_move(delta):
            return
        self.moves.append(move)
        for a in self.enemies:
            a.tick()
        tomove = self.enemies[:]
        more = True
        while more:
            more = False
            for a in tomove[:]:
                if a.act(self, False):
                    tomove.remove(a)
                    more = True
                    break
            if more:
                continue
            for a in tomove[:]:
                if a.act(self, True):
                    tomove.remove(a)
                    more = True
                    break
        topush = self.enemies[:] + [self.player]
        self.conveyer(topush, False)
        self.conveyer(topush, True)
